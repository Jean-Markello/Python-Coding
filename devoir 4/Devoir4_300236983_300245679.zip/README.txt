Nom étudiant : Jean Markello Létang
Numéro d’étudiant : 300245679

Nom étudiant : Maxime Couture
Numéro d’étudiant : 300236983

Code du cours : ITI1520
Section Lab: Lab6

Description:
    Ce fichier contient les question 1,2,3,4,5 du devoir 4