def pgcd(x,y):
    if x%y==0:
        return y
    else:
        return pgcd(y,x%y)

print(pgcd(1234,4321))
print(pgcd(8192,192))