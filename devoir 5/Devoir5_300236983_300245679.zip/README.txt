Nom étudiant : Jean Markello Létang
Numéro d’étudiant : 300245679

Nom étudiant : Maxime Couture
Numéro d’étudiant : 300236983

Code du cours : ITI1520
Section Lab: Lab8 

Description:
    Ce fichier contient les question 1 et 2 du devoir 5