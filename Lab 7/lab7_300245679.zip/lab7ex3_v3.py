def move_zeros_v3(x):
    f=0
    nzero=0
    while f+nzero<len(x):
        if x[f]==0:
            nzero+=1
            for i in range(f,len(x)-1):
                x[i]=x[i+1]
            x[-1]=0
        else:
            f+=1

l=[1,0,3,0,0,5,7]
z=move_zeros_v3(l)
print(l,z) 